package com.example.lifeline24_7

import android.app.Service
import android.content.Intent
import android.os.IBinder

class fire_detection : Service() {

    override fun onBind(intent: Intent): IBinder {

        TODO("Return the communication channel to the service.")
    }
}